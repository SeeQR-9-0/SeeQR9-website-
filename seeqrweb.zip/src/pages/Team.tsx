import React from 'react'

export default function Team() {
  return (
    <div>Team</div>
  )
}
